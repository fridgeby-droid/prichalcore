import json
import os
import threading

_LOCK = threading.RLock()


def load_users(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except Exception:
        return []


def get_user_profile(user_id, users_file, admins=None):
    if not user_id:
        return None
    users = load_users(users_file)
    for user in users:
        if int(user.get("telegram_id", 0)) == int(user_id):
            profile = dict(user)
            profile["is_admin"] = bool(admins and int(user_id) in admins)
            return profile
    return {
        "telegram_id": int(user_id),
        "name": "Пользователь",
        "role": "admin" if admins and int(user_id) in admins else "seller",
        "observed_store_ids": [],
        "is_admin": bool(admins and int(user_id) in admins),
    }
