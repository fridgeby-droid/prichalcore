import json
import os
import threading

_LOCK = threading.RLock()


def _read_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _write_json(path, data):
    tmp = f"{path}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    os.replace(tmp, path)


def ensure_store_catalog(shops, catalog_file):
    """Synchronize legacy shops dict with a stable numeric ID catalog."""
    with _LOCK:
        catalog = _read_json(catalog_file, [])
        if not isinstance(catalog, list):
            catalog = []

        by_name = {row.get("name"): row for row in catalog if row.get("name")}
        max_id = max([int(row.get("store_id", 0)) for row in catalog] or [0])

        changed = False
        current_names = set(shops.keys())
        for name in shops.keys():
            if name not in by_name:
                max_id += 1
                row = {"store_id": max_id, "name": name, "active": True}
                catalog.append(row)
                by_name[name] = row
                changed = True
            elif not by_name[name].get("active", True):
                by_name[name]["active"] = True
                changed = True

        for row in catalog:
            if row.get("name") not in current_names and row.get("active", True):
                row["active"] = False
                changed = True

        if changed or not os.path.exists(catalog_file):
            _write_json(catalog_file, catalog)
        return catalog


def store_id_for_name(name, shops, catalog_file):
    catalog = ensure_store_catalog(shops, catalog_file)
    for row in catalog:
        if row.get("name") == name:
            return row.get("store_id")
    return None


def active_stores(shops, catalog_file):
    return [row for row in ensure_store_catalog(shops, catalog_file) if row.get("active", True)]
