import hashlib
import hmac
import json
import time
import urllib.parse


def validate_init_data(init_data: str, bot_token: str, max_age_seconds: int = 86400):
    """Validate Telegram Mini App initData and return the user dict.

    Returns None for missing/invalid data. This deliberately fails closed for
    privileged operations while legacy seller endpoints may still choose to
    operate without an authenticated user.
    """
    if not init_data or not bot_token:
        return None

    try:
        parsed = urllib.parse.parse_qsl(init_data, keep_blank_values=True)
        fields = dict(parsed)
        received_hash = fields.pop("hash", None)
        if not received_hash:
            return None

        data_check_string = "\n".join(
            f"{key}={value}" for key, value in sorted(fields.items())
        )
        secret_key = hmac.new(
            b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256
        ).digest()
        calculated_hash = hmac.new(
            secret_key, data_check_string.encode("utf-8"), hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(calculated_hash, received_hash):
            return None

        auth_date = fields.get("auth_date")
        if auth_date and max_age_seconds > 0:
            try:
                age = int(time.time()) - int(auth_date)
                if age < -60 or age > max_age_seconds:
                    return None
            except (TypeError, ValueError):
                return None

        user_raw = fields.get("user")
        if not user_raw:
            return None
        user = json.loads(user_raw)
        return user if isinstance(user, dict) and user.get("id") else None
    except Exception:
        return None


def get_user_id(init_data: str, bot_token: str, max_age_seconds: int = 86400):
    user = validate_init_data(init_data, bot_token, max_age_seconds)
    return user.get("id") if user else None


def get_user_name(init_data: str, bot_token: str, max_age_seconds: int = 86400):
    user = validate_init_data(init_data, bot_token, max_age_seconds)
    if not user:
        return "Пользователь"
    parts = [user.get("first_name", "").strip(), user.get("last_name", "").strip()]
    name = " ".join(part for part in parts if part)
    return name or user.get("username") or "Пользователь"
