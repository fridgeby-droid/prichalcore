# Core helpers for the v2 foundation.
