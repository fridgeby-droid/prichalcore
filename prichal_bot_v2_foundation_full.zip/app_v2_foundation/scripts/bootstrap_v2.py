import json
import os
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from config import ORDERS_FILE, SHOPS_FILE, ADMINS_FILE, USERS_FILE, STORE_CATALOG_FILE
from core.store_registry import ensure_store_catalog


def load(path, default):
    p = Path(path)
    if not p.exists():
        return default
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def atomic_write(path, data):
    p = Path(path)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, p)


def main():
    shops = load(SHOPS_FILE, {})
    orders = load(ORDERS_FILE, [])
    admins = set(load(ADMINS_FILE, []))
    catalog = ensure_store_catalog(shops, STORE_CATALOG_FILE)
    store_by_name = {row["name"]: row["store_id"] for row in catalog}

    backup_dir = ROOT / "backup"
    backup_dir.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"orders_before_v2_{stamp}.json"
    shutil.copy2(ORDERS_FILE, backup_path)

    migrated = 0
    unknown_shops = set()
    user_stats = {}

    for order in orders:
        shop = order.get("shop")
        sid = store_by_name.get(shop)
        if sid is None and shop:
            unknown_shops.add(shop)
        if order.get("store_id") != sid:
            order["store_id"] = sid
            migrated += 1

        uid = order.get("user_id")
        if uid:
            uid = int(uid)
            row = user_stats.setdefault(uid, {
                "telegram_id": uid,
                "name": order.get("user_name") or "Пользователь",
                "role": "admin" if uid in admins else "seller",
                "observed_store_ids": set(),
                "active": True,
            })
            if order.get("user_name") and order.get("user_name") != "Пользователь":
                row["name"] = order.get("user_name")
            if sid:
                row["observed_store_ids"].add(sid)

    for uid in admins:
        user_stats.setdefault(int(uid), {
            "telegram_id": int(uid),
            "name": "Администратор",
            "role": "admin",
            "observed_store_ids": set(),
            "active": True,
        })

    users = []
    for uid in sorted(user_stats):
        row = user_stats[uid]
        row["observed_store_ids"] = sorted(row["observed_store_ids"])
        users.append(row)

    atomic_write(ORDERS_FILE, orders)
    atomic_write(USERS_FILE, users)

    print(f"Store catalog: {len(catalog)}")
    print(f"Orders: {len(orders)}; store_id added/updated: {migrated}")
    print(f"Users: {len(users)}")
    print(f"Backup: {backup_path}")
    if unknown_shops:
        print("Unknown shops:", ", ".join(sorted(unknown_shops)))


if __name__ == "__main__":
    main()
